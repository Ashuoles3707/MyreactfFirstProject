import React, { useState, useEffect } from "react";
import axios from "axios";

function MobilesViews() {
  const [mobiles, setMobiles] = useState([]);  
  const [cartItems, setCartItems] = useState([]);  
  const [error, setError] = useState("");

  // Fetch mobile data on component mount
  useEffect(() => {
    axios
      .get("http://localhost:8080/mob") // API endpoint
      .then((response) => {
        setMobiles(response.data); // Store fetched data
      })
      .catch((error) => {
        setError("Failed to load mobile data");
        console.error("Error fetching data:", error);
      });
  }, []);

  // Function to add an item to the cart
  const addToCart = (mobile) => {
    setCartItems([...cartItems, mobile]); // Add mobile to cart
  };

  // Function to remove an item from the cart
  const removeFromCart = (index) => {
    const updatedCart = [...cartItems];
    updatedCart.splice(index, 1); // Remove item at index
    setCartItems(updatedCart);
  };

  return (
    <div className="container mt-4">
      <h2 className="text-center text-white">📱 Mobile Store</h2>

      {error && <p className="text-danger text-center">{error}</p>}

      {/* Mobile Items - Card View */}
      <div className="row">
        {mobiles.map((mob) => (
          <div key={mob.m_id} className="col-md-4 mb-4">
            <div className="card text-center bg-dark text-light">
              <img
                src={mob.image || "https://via.placeholder.com/150"}
                alt={mob.mobile_name}
                className="card-img-top"
                style={{ height: "200px", objectFit: "cover" }}
              />
              <div className="card-body">
                <h5 className="card-title">{mob.mobile_name}</h5>
                <p className="card-text">Brand: {mob.brand_name}</p>
                <p className="card-text">Price: ₹{mob.price}</p>
                <button className="btn btn-success w-100" onClick={() => addToCart(mob)}>
                  Add to Cart 🛒
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cart Section */}
      {cartItems.length > 0 && (
        <div className="mt-5">
          <h3 className="text-white text-center">🛒 Your Cart</h3>
          <div className="row">
            {cartItems.map((item, index) => (
              <div key={index} className="col-md-4 mb-4">
                <div className="card text-center bg-secondary text-light">
                  <img
                    src={item.image || "https://via.placeholder.com/150"}
                    alt={item.mobile_name}
                    className="card-img-top"
                    style={{ height: "200px", objectFit: "cover" }}
                  />
                  <div className="card-body">
                    <h5 className="card-title">{item.mobile_name}</h5>
                    <p className="card-text">Brand: {item.brand_name}</p>
                    <p className="card-text">Price: ₹{item.price}</p>
                    <button className="btn btn-danger w-100" onClick={() => removeFromCart(index)}>
                      Remove ❌
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default MobilesViews;
