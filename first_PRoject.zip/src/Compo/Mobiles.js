import React, { useState } from "react";
import axios from "axios";

function Mobiles() {
  const [mob, setMob] = useState({
    m_id: "",
    mobile_name: "",
    brand_name: "",
    price: "",
    image: "",
    descrip: "",
  });

  const [resMessage, setRes] = useState("");

  const handleChange = (e) => {
    setMob({ ...mob, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post("http://localhost:8080/mob/addMob", mob)
      .then(() => {
        setRes("Mobile details added successfully");
        setMob({ m_id: "", mobile_name: "", brand_name: "", price: "", image: "", descrip: "" });
      })
      .catch(() => setRes("Failed to add mobile details"));
  };

  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-dark">
      <div className="card shadow-lg text-light bg-secondary" style={{ width: "400px" }}>
        <div className="card-header text-center text-white">
          <h4>Mobile Register</h4>
        </div>
        <div className="card-body">
          <form onSubmit={handleSubmit}>
            <div className="mb-3">
              <label className="form-label">Mobile Id</label>
              <input type="text" name="m_id" value={mob.m_id} onChange={handleChange} className="form-control" placeholder="Enter Mobile Id" required />

              <label className="form-label">Mobile Name</label>
              <input type="text" name="mobile_name" value={mob.mobile_name} onChange={handleChange} className="form-control" placeholder="Enter Mobile Name" required />

              <label className="form-label">Mobile Brand</label>
              <input type="text" name="brand_name" value={mob.brand_name} onChange={handleChange} className="form-control" placeholder="Enter Mobile Brand" required />

              <label className="form-label">Mobile Price</label>
              <input type="text" name="price" value={mob.price} onChange={handleChange} className="form-control" placeholder="Enter Mobile Price" required />

              <label className="form-label">Mobile Img</label>
              <input type="text" name="image" value={mob.image} onChange={handleChange} className="form-control" placeholder="Enter Mobile Image URL" />
              
              <label className="form-label">Mobile Descript</label>
              <input type="text" name="descrip" value={mob.descrip} onChange={handleChange} className="form-control" placeholder="Enter Mobile Image URL" />
            </div>

            <button type="submit" className="btn btn-primary w-100" style={{ backgroundColor: "#abeb34" }}>
              Add
            </button>
          </form>

          {resMessage && <p className="text-center mt-3">{resMessage}</p>}

          {mob.image && (
            <img src={mob.image} alt="Mobile Preview"  className="d-block mx-auto mt-4 rounded" style={{ width: "100px", height: "100px" }} />
          )}
        </div>
      </div>
    </div>
  );
}

export default Mobiles;
