function About(){
    return(
        <div className=" text-light vh-100 d-flex flex-column justify-content-center align-items-center text-center" style={{ backgroundColor: " #656663"}}>  
        {/* About Section */}
        <section id="about" className="container py-5 text-center">
          <h2 className="text-center mb-4">About Me</h2>
          <p className="mx-auto" style={{ maxWidth: "600px" }}>
            Hi! I'm a passionate software developer with experience in building web applications.
            I specialize in front-end and back-end technologies, creating responsive and user-friendly designs.
          </p>
        </section>
  
        
      </div>
    
    )
}
export default About;