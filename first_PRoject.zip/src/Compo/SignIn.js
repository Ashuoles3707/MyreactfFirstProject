import React from "react";
import {  useNavigate } from "react-router-dom";
import "@fortawesome/fontawesome-free/css/all.min.css";

const SignIn = () => {
    var navigate = useNavigate();
    var frogot=()=>{
        navigate("/ForgotPassword");
    }
     var regi=()=>{
        navigate("/SignUp");
    }
  return (
    <div className="d-flex justify-content-center align-items-center vh-100 " style={{ backgroundColor: " #656663"}}>
      <div className="card shadow-lg text-light bg-secondary" style={{ width: "400px" }}>
        <div className="card-header text-center  text-white">
          <h4>Sign In</h4>
        </div>
        <div className="card-body">
          <form>
            <div className="mb-3">
              <label htmlFor="email" className="form-label">Email Address</label>
              <input type="email" className="form-control" id="email" placeholder="Enter your email" required />
            </div>
            <div className="mb-3">
              <label htmlFor="password" className="form-label">Password</label>
              <input type="password" className="form-control" id="password" placeholder="Enter your password" required />
            </div>
            <div className="mb-3">
              <input type="checkbox" className="form-check-input" id="rememberMe" />
              <label className="form-check-label ms-2" htmlFor="rememberMe">Remember me</label>
              <a onClick={frogot} href="#" className="float-end text-white">Forgot password?</a>
            </div>
            <button type="submit" className="btn btn-primary w-100" style={{ backgroundColor: " #abeb34"}}>Sign In</button>
          </form>
        </div>
        <div className="card-footer text-center">
          <small>Not a member? <a onClick={regi} href="#" className="text-light">Register</a></small>
          <p className="mt-2">or sign in with:</p>
          <div className="d-flex justify-content-center gap-3">
            <i className="fab fa-facebook fa-lg"></i>
            <i className="fab fa-google fa-lg"></i>
            <i className="fab fa-twitter fa-lg"></i>
            <i className="fab fa-github fa-lg"></i>
          </div>
        </div><br></br>
      </div>
    </div>
  );
};

export default SignIn;
