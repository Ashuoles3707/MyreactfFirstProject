import React from "react";
import {useState} from "react";

function Mobile(){
    var [stu,setStu] =useState({Mid:'',Mname:'',Mbrand:'',Mprice:''});
    var handleChange = (e) =>{
        var {name,value} = e.target;
        setStu({...stu,[name]:value});
    }
  return (
    <div className="d-flex justify-content-center align-items-center vh-100 bg-dark">
      <div className="card shadow-lg text-light bg-secondary" style={{ width: "400px" }}>
        <div className="card-header text-center  text-white">
          <h4>Mobile Register</h4>
        </div>
        <div className="card-body">
          <form>
            <div className="mb-3">
              <label  className="form-label">Mobile Id</label>
              <input type="text" name="Mid" value={stu.Mid} onChange={handleChange} className="form-control"  placeholder="Enter Mobile Id" required />
              <label  className="form-label">Mobile Name</label>
              <input type="text" name="Mname" value={stu.Mname} onChange={handleChange} className="form-control"  placeholder="Enter Mobile Name" required />
              <label  className="form-label">Mobile Brand</label>
              <input type="text" name="Mbrand" value={stu.Mbrand} onChange={handleChange} className="form-control"  placeholder="Enter Mobile Brand" required />
              <label  className="form-label">Mobile Price</label>
              <input type="text" name="Mprice" value={stu.Mprice} onChange={handleChange} className="form-control"  placeholder="Enter Mobile Price" required />
              <label  className="form-label">Mobile Img</label>
              <input type="text" className="form-control" id="email" placeholder="Enter Mobile Img"  />
            </div>
            <button type="submit" className="btn btn-primary w-100" style={{ backgroundColor: " #abeb34"}}>Add</button>
          </form>
          <h1>{stu.Mid}</h1>
          <h1>{stu.Mname}</h1>
          <h1>{stu.Mbrand}</h1>
          <h1>{stu.Mprice}</h1>
        </div>
      </div>
    </div>
  );
};


export default Mobile;