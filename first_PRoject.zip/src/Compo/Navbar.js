import { Link } from "react-router-dom";
import "./Navbar.css"


function Navbar(){
     
    return(
        <div className="n">
            <Link to="/">
                <img className="im" src="https://cdn-icons-png.flaticon.com/128/888/888846.png" alt="Home Logo" />
            </Link>
            <Link to="/" className="comp"><h4>Home</h4></Link>
            <Link to="/about" className="comp"><h4>About</h4></Link>
            <Link to="/signin" className="comp"><h4>SignIn</h4></Link>
            <Link to="/signup" className="comp"><h4>SignUp</h4></Link>
        </div>
    )
}
export default Navbar;