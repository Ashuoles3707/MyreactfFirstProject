import React, { useState, useEffect } from "react";
import axios from "axios";
import "./MobileView.css";
function MobilesView() {
  const [mobiles, setMobiles] = useState([]);
  const [error, setError] = useState("");

 
  useEffect(() => {
    axios
      .get("http://localhost:8080/mob") 
      .then((response) => {
        setMobiles(response.data); 
      })
      .catch((error) => {
        setError("Failed to load mobile data");
        console.error("Error fetching data:", error);
      });
  }, []);

  return (
    <div >
     
      <div>
        {mobiles.map((mob)=> (
          <div className="pro1"><br></br>
              <img src={mob.image} className="im1"/>
              <h2>{mob.mobile_name}</h2>
              <p>
                {mob.descrip}
              </p>
              <h3>{mob.brand_name}</h3>
              <h5>Price: {mob.price}</h5>
           </div>
        ))}
      </div>
              
              
    </div>
  );
}

export default MobilesView;
