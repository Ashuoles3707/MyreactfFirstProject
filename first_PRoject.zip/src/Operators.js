function Operators(){
    var a=10;
    var b=10;
    var c="";

    return(

        <div>
            {/* //and Operators */}
            {a==b && <h1>Its True</h1>}

            {/* // or Operators */}
            {c|| <h1>its Or's output</h1>}

            {/* // ternary Operators */}
            {a==b ? <h1>its true T</h1> : <h1>Its False T</h1>}
        </div>
    );
}
export default Operators;