
function Pure(){
    function pure(a,b){
        return a+b;
    }
    var r = 500;

    function imPure(p,q){
        return p+q+r;
    }

    const pures = pure(5, 10); 
    const imPures = imPure(5, 10);

    return(
        <div>
            <h3>Pure Function Result:</h3>
            <p>{pures}</p>
            <h3>Impure Function Result:</h3>
            <p>{imPures}</p>
        </div>
    )
}
export default Pure;