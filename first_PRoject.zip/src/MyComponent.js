import React from "react";
import {memo} from "react";
const MyComponent = React.memo(({ value })=>{
    console.log("Rendered");
    return <div><h1>{value}</h1></div>
});
export default MyComponent;

//it the 