// import "./MyFun.css";
function MyFunction(props){
    // var a= 30;
    return(
        <div style={{backgroundColor:props.col,height:"700px"}}>
            <h1>Hello From MyFunction </h1>
            <h1>Hello {props.name}</h1>
            <h2>I Am Subcribed {props.channel} </h2>
        </div>
    )
}
export default MyFunction;