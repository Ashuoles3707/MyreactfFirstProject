import React,{Component} from "react";
class MyClass extends React.Component{

    constructor(props){
        super(props);
        this.state={
            s:"Ashu"
        }
    }
    change(){
        this.setState({s:"Chetan"});
    }
    render(){
        return(
            <div style={{backgroundColor:this.props.col,height:"700px"}}>
                {/* <h1>Hello From MyClass </h1>
                <h1>Hello {this.props.name}</h1>
                <h2>My Instagram Followers is {this.props.foll}</h2>
                <h2>My Youtube Followers is {this.props.follo}</h2> */}

                <h1>Hello {this.state.s}</h1>
                <button onClick={()=>{this.change()}}>Sub</button>
            </div>
        )}
    }
    export default MyClass;