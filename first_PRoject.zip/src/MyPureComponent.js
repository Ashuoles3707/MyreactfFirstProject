import React from "react";

export default class MyPureComponent extends React.PureComponent{
    render(){
        return(
            <div>
                Hello from {this.props.value}
            </div>
        )
    }
}