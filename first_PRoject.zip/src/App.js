

import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';
// import About from './Compo/About';
// import Home from './Compo/Home';
// import Navbar from './Compo/Navbar';
// import SignIn from './Compo/SignIn';
// import SignUp from './Compo/Signup';
// import ForgotPassword from './Compo/ForgotPassword';
// import Mobiles from './Compo/Mobiles';
// import MobileView from "./Compo/MobileView";
// import MobilesViews from './Compo/MobilesViews';

import UseRed from './UseRed';
import ConPro from  './ConPro';
import Auth from './Auth';
import { useState } from 'react';
import MyComponent from './MyComponent';
import MyPureComponent from './MyPureComponent';

// import Testusestate from "./Testusestate"
// import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  const [uStatus,setuStatus]=useState(false);
  const login =()=>{
    setuStatus(true);
  };
return(
  <div>
    
    <div>
      {/* { <BrowserRouter>
      <Navbar /> */}
        {/* <Routes>
        <Route path="/" element={<Home />} /> 
        <Route path="/mobiles" element={<Mobiles />} /> 
        <Route path="/mobileview" element={<MobileView />} /> 
        <Route path='/mobileviews' element={MobilesViews}/>
        <Route path="/about" element={<About />} />
        <Route path="/signin" element={<SignIn />} />
        <Route path="/forgotpassword" element={<ForgotPassword />} />
        <Route path="/signup" element={<SignUp />} />
        </Routes> */}
        
      {/* </BrowserRouter> } */}
      {/* <Testusestate/> */}
          <div>

          <ConPro.Provider value={{ status: uStatus , login: login}}>
      <Auth/>
      </ConPro.Provider>
      <button onClick={login}>Submit</button>

          </div>
      
      <UseRed/>
      <MyComponent value="Ashutosh"/>
      <MyPureComponent value="Olekar"/>
    </div>

  </div>
  
)
}

export default App;