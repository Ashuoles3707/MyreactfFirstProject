import { useState } from "react";

function Testusestate() {
    var color = ["red","blue","green","pink","orange"];

    var [x, setX] = useState({ backgroundColor:color[0],index:0 });

    var fun = () => {
        let newIndex = (x.index + 1) % color.length; 
        setX({ backgroundColor: color[newIndex], index: newIndex });
    };

    return (
        <div style={{ ...x, height: "100vh", display: "flex", justifyContent: "center", alignItems: "center" }}>
            <button onClick={fun} style={{ padding: "10px 20px", fontSize: "16px" }}>
                Change Color
            </button>
        </div>
    );
}

export default Testusestate;
