function MainApp(){
    let name = "Ashu";
  var arr =[10,20,30,40,50,60,70,80,90,100];
  var stringarr = ["ashutosh","nikhil","chetan","raj"];
  var students = [
    {
      name: "Ashutosh",
      age: 25,
      course: "Full-Stack Development",
      skills: ["HTML", "CSS", "JavaScript", "Spring Boot"],
    }
  ]
  return (
    <div >
      <h1>Hello {name}</h1>
      <hr></hr>
      {/* number array */}
      <div>
        {arr.map((m)=>(<p>{m}</p>))}
      </div>
      <hr></hr>
       {/* String array */ }
      <div>
        {stringarr.map((m)=>(<p>{m}</p>))}
      </div>
      <hr></hr>
       {/* object array */}
      <div>
        {/* {students.map((index)=>(<h1>{index}</h1>))} */}
        {students.map((student, index) => (
        <div key={index}>
          <p>Name: {student.name}</p>
          <p>Age: {student.age}</p>
          <p>Course: {student.course}</p>
          <p>Skills: {student.skills.join(", ")}</p>
        </div>
      ))}
      </div>
    </div>
  );
}
export default MainApp;