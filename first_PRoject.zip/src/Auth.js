import { useContext } from "react";
import ConPro from "./ConPro";

function Auth(){
    var auth = useContext(ConPro);
    console.log(auth.status);
    return(
        <div>
            Are You Authanticated ? {auth.status ? <h1>Hello From Auth</h1> : <h2>Its false</h2>}
        </div>
    )
}export default Auth;