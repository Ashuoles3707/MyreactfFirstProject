import { useState } from "react";

function MyState(){
    var [x,setX] = useState(1);
    var fun = ()=>{
        setX(x+1);
    }
    var [y,setY] = useState("Ashutosh");
    var string=()=>{
        setY("Chetan");
    }

    var [ob,setOB] = useState({id:1,name:"Ashutosh",age:26});
    var obje=()=>{
        setOB({id:2,name:"Chetan",age:27});
    } 
    
    var [ob1,setOB1] = useState({id:1,name:"Ashutosh",age:26});
    
    var [arr,setARR] = useState (["ashutosh","chetan","nikhil"]);
    var arre=()=>{
        setARR(["lokesh","raj","niraj"]);
    }
    return(
        <div>
            <h1>{arr}</h1>
            <button onClick={arre}>change</button>

            <h1>{x}</h1>
            <button onClick={fun}>change</button>

            <h1>{y}</h1>
            <button onClick={string}>change</button>

            <h1>{ob.id}</h1> <h1>{ob.name}</h1> <h1>{ob.age}</h1>
            <button onClick={obje}>change</button>
            
            <h1>{ob1.id}</h1> <h1>{ob1.name}</h1> <h1>{ob1.age}</h1>
            <button onClick={()=>{setOB1({id:2,name:"Chetan",age:27})}}>change</button>


        </div>
    )
}
export default MyState;