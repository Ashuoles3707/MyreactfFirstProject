import React from "react";
var ConPro = React.createContext({status:null,login:()=>{}});
export default ConPro;